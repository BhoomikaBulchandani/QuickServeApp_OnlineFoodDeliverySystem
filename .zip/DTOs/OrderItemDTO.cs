﻿namespace QuickServeAPP.DTOs
{
    public class OrderItemDto
    {
        public int MenuID { get; set; }
        public int Quantity { get; set; }
    }
}
