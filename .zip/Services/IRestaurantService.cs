﻿using QuickServeAPP.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using QuickServeAPP.DTOs;

namespace QuickServeAPP.Services
{
    public interface IRestaurantService
    {
        Task<RestaurantDto> CreateRestaurantAsync(RestaurantDto restaurantDto);
        Task<IEnumerable<RestaurantDto>> GetAllRestaurantsAsync();
        Task<RestaurantDto> GetRestaurantByIdAsync(int restaurantId);
        Task<RestaurantDto> UpdateRestaurantAsync(int restaurantId, RestaurantDto restaurantDto);
        Task DeleteRestaurantAsync(int restaurantId);
    }
}


